create procedure kill_session
    ( v_sid number, v_serial number )
    as
    v_varchar2 varchar2(100);
    begin
    execute immediate 'ALTER SYSTEM KILL SESSION '''
    || v_sid || ',' || v_serial || '''';
  end;
/

