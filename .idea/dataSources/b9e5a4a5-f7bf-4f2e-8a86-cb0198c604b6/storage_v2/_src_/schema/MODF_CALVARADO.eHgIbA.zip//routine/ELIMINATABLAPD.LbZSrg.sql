create procedure eliminaTablaPD
as 
begin 
    EXECUTE IMMEDIATE 'DROP TABLE TEMP_PRODDOS';
end;
/

