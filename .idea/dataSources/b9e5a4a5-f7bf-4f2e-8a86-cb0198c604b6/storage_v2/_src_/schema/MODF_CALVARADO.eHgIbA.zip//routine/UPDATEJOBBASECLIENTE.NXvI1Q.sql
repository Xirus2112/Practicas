create PROCEDURE updateJobBaseCliente AS 
BEGIN    
    UPDATE 	JOB_BASECLIE a 
    SET 	a.LEIDO = 1
    WHERE	a.PRODUCTO IN (SELECT PRODUCTO FROM JOB_LECTURBI);       

    UPDATE 	JOB_BASECLIE a
    SET		a.UniversoFacturable = 1
    WHERE   a.NIC IN (SELECT nic  FROM JOB_UNIVFACT );    

    UPDATE 	JOB_BASECLIE a
    SET		a.FACTURADO = 1
    WHERE	a.NIC  IN (SELECT b.NIC FROM JOB_PRODFACT b);

    UPDATE 	JOB_BASECLIE a
    SET		a.IMPRESOOPEN = 1
    WHERE	a.NIC IN (SELECT b.NIC FROM JOB_PRODFACT b WHERE b.IMPRESA = 1 );

    UPDATE 	JOB_BASECLIE a
    SET		a.IMPRESOINFO= 1
    WHERE	a.NIC IN (SELECT b.Nic FROM JOB_IMPRINFO b);

    UPDATE 	JOB_BASECLIE a 
    SET		a.LECTURAGENERADA = 1
    WHERE	a.PRODUCTO IN (SELECT b.PRODUCTO FROM JOB_GENELECT b);

    UPDATE 	JOB_BASECLIE a 
    SET		a.CONMEDIDA = 1 
    WHERE	a.producto IN  (SELECT b.PRODUCTO FROM JOB_CONMEDIDF b);

    UPDATE 	JOB_BASECLIE a 
    SET 	a.CARGOSNEGATIVOS = 1
    WHERE	a.PRODUCTO in (SELECT b.PRODUCTO FROM JOB_CARGNEGA b);

    UPDATE  JOB_BASECLIE a
    SET     (a.PCOBROACTUAL,a.CONSUMOACTUAL,a.TERCEROS
            ) = (/*+ INDEX( SYS_C0020403 ) */ SELECT b.PCOBRO,b.CONSUMOSKWH,b.TERCEROS
                FROM JOB_PUESCOBR b WHERE a.NIC = b.NIC
                )
    WHERE EXISTS ( /*+ INDEX( SYS_C0020403 ) */ 
                SELECT b.PCOBRO,b.CONSUMOSKWH,b.TERCEROS
                FROM JOB_PUESCOBR b WHERE a.NIC = b.NIC
                );

    UPDATE  JOB_BASECLIE a
    SET     (
            a.PCOBROANTERIOR
            ) = (
                /*+
                    INDEX( JOB_PRPCANTE_NIC_IDX )
                */            
                SELECT  b.PCOBRO
                FROM    JOB_PRPCANTE b
                WHERE   a.NIC = b.NIC
                )
    WHERE EXISTS (
                /*+
                    INDEX( JOB_PRPCANTE_NIC_IDX )
                */
                SELECT  b.PCOBRO
                FROM    JOB_PRPCANTE b
                WHERE   a.NIC = b.NIC
                );
COMMIT;

END updateJobBaseCliente;
/

